var perTicket = 59;
var bookingFee = 9;
var $subTotal = $('#total');

$('input[type="number"]').on('input', function() {
  if (!$(this).val().trim().length) return;
  var total = $(this).val() * perTicket + bookingFee;
  $subTotal.text(total);

})

